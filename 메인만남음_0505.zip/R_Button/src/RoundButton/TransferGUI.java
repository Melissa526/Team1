package RoundButton;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class TransferGUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JLabel banner_transfer;
	// 1.
	private JPanel panel_transfer_top, panel_transfer_mid, panel_transfer_bottom;
	private JButton btn_transfer, btn_goback;
	private JTextField accountjField, inputField, messageField;
	private JLabel label_account, label_money, label_message;
	private BankBiz biz = new BankBiz();
	private BankDto my;
	private CheckPW passwordChk;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TransferGUI frame = new TransferGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TransferGUI() {}
	public TransferGUI(BankDto logindto) {
		my = logindto;
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		Dimension frameSize = this.getSize(); // ������ ������
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // ����� ������
		this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.window);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		// 2.
		panel_transfer_top = new JPanel();
		panel_transfer_top.setBounds(0, 0, 800, 100);
		panel_transfer_mid = new JPanel();
		panel_transfer_mid.setBackground(SystemColor.window);
		panel_transfer_mid.setBounds(0, 100, 800, 331);
		panel_transfer_bottom = new JPanel();
		panel_transfer_bottom.setBackground(SystemColor.window);
		panel_transfer_bottom.setBounds(0, 430, 800, 122);

		label_message = new JLabel("�޴� �� ����޸�");
		label_message.setBounds(148, 228, 150, 40);
		label_message.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label_message.setHorizontalAlignment(SwingConstants.CENTER);

		messageField = new JTextField(40);
		messageField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					btn_transfer.requestFocus();
				}
			}
		});
		messageField.setBackground(SystemColor.text);
		messageField.setBounds(299, 224, 354, 50);
		btn_transfer = new JButton("��   ü");
		btn_transfer.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		btn_transfer.setBounds(243, 6, 150, 50);
		btn_transfer.setBackground(SystemColor.control);
		btn_transfer.setForeground(new Color(0, 0, 0));
		btn_goback = new JButton("�ǵ��� ����");
	
		btn_goback.setBackground(SystemColor.control);
		btn_goback.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		btn_goback.setBounds(422, 7, 150, 50);
		panel_transfer_bottom.add(btn_goback);
		contentPane.setLayout(null);

		panel_transfer_mid.setLayout(null);
		label_account = new JLabel("�޴� �� ���¹�ȣ");
		label_account.setBounds(148, 102, 150, 40);
		label_account.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label_account.setHorizontalAlignment(SwingConstants.CENTER);

		panel_transfer_mid.add(label_account);
		accountjField = new JTextField(40);
		accountjField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(accountjField.getText().length() == 11 || e.getKeyChar() == KeyEvent.VK_ENTER) {
					inputField.requestFocus();
				}
			}
		});
		accountjField.setBackground(SystemColor.text);
		accountjField.setBounds(299, 98, 354, 50);
		panel_transfer_mid.add(accountjField);
		label_money = new JLabel("������ �ݾ�");
		label_money.setBounds(148, 165, 150, 40);
		label_money.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		label_money.setHorizontalAlignment(SwingConstants.CENTER);
		panel_transfer_mid.add(label_money);
		inputField = new JTextField(20);
		inputField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					messageField.requestFocus();
				}
			}
		});
		inputField.setBackground(SystemColor.text);
		inputField.setForeground(Color.BLACK);
		inputField.setBounds(299, 161, 354, 50);
		panel_transfer_mid.add(inputField);
		panel_transfer_mid.add(label_message);
		panel_transfer_mid.add(messageField);
		panel_transfer_bottom.setLayout(null);
		panel_transfer_bottom.add(btn_transfer);

		// event
		btn_transfer.addActionListener(this);
		btn_goback.addActionListener(this);
		contentPane.setLayout(null);

		// 4.
		getContentPane().add(panel_transfer_top);
		ImageIcon img = new ImageIcon("images/banner_transfer.png");
		Image preImg = img.getImage(); // ImageIcon�� Image�� ��ȯ.
		Image afterImg = preImg.getScaledInstance(800, 100, java.awt.Image.SCALE_SMOOTH);
		ImageIcon afterIcon = new ImageIcon(afterImg); // Image�� ImageIcon ����
		panel_transfer_top.setLayout(new GridLayout(0, 1, 0, 0));
		banner_transfer = new JLabel("");
		panel_transfer_top.add(banner_transfer);
		banner_transfer.setVerticalAlignment(SwingConstants.TOP);
		banner_transfer.setIcon(afterIcon);
		getContentPane().add(panel_transfer_mid);
		
		JLabel balanceLabel = new JLabel("���� �ܾ�  : ");
		balanceLabel.setHorizontalAlignment(SwingConstants.CENTER);
		balanceLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
		balanceLabel.setBounds(203, 29, 150, 40);
		panel_transfer_mid.add(balanceLabel);
		
		JLabel balanceLabel2 = new JLabel("");
		balanceLabel2.setText(my.getT_balance()+"");
		balanceLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
		balanceLabel2.setFont(new Font("���� ����", Font.PLAIN, 18));
		balanceLabel2.setBounds(311, 29, 243, 40);
		panel_transfer_mid.add(balanceLabel2);
		
		JLabel label = new JLabel("��");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Dialog", Font.PLAIN, 16));
		label.setBounds(554, 29, 56, 40);
		panel_transfer_mid.add(label);
		getContentPane().add(panel_transfer_bottom);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn_transfer) {
			String trans_account = accountjField.getText();
			String trans_message = messageField.getText();
			int trans_money = Integer.parseInt(inputField.getText());
			transferMoney(my, trans_account, trans_money, trans_message);
		} else if (e.getSource() == btn_goback) {
			
			if(JOptionPane.showConfirmDialog(null, "�� �������� �����ðڽ��ϱ�?", "�ǵ��� ����", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE)==0) {
				RoundButton2 roundButton2 = new RoundButton2(my);
				roundButton2.setVisible(true);
				dispose();
			}
		}
	}

	public void transferMoney(BankDto sender, String receiverAccount, int sendMoney, String message) {
		String processRes = "";

		// (1)���� ��ȿ�� �˻�
		if (biz.accountCheck(receiverAccount)) {
			System.out.println("++++++ ���� ��ȿ�� OK! ++++++");
			// (2)�ܾ� �˻�
			if (my.getT_balance() >= sendMoney) {
				System.out.println("++++++ �ŷ��ܾ� OK! ++++++");
				// (3-0) ���ΰ��� ����Ȯ��
				if (!sender.getAccount().equals(receiverAccount)) {
					// (3)������ Ȯ��
					if (JOptionPane.showConfirmDialog(null,"[" + biz.selectOne(receiverAccount).getName() + "]�Բ� ��ü�Ͻðڽ��ϱ�?",
							"������ Ȯ��â", JOptionPane.YES_NO_OPTION) == 0) {
						// (4) ��й�ȣ Ȯ��
						passwordChk = new CheckPW(this, "��й�ȣ Ȯ��", sender);
						passwordChk.setVisible(true);
						if (passwordChk.isPwChk()) {
							System.out.println("++++++ ��й�ȣ Ȯ�� OK! ++++++");
							// (5)�� ���� ���
							processRes += biz.updateBalance(sender, sender.getAccount(), -sendMoney, "��ü���");
							// (6)��� ���� �Ա�
							processRes += biz.updateBalance(sender, receiverAccount, sendMoney, message);
							if (processRes.equals("22")) {
								JOptionPane.showMessageDialog(null, "���������� ��ü�Ǿ����ϴ�.", "��ü �Ϸ�!", JOptionPane.INFORMATION_MESSAGE);
								System.out.println("++++++ ������ü OK! ++++++");
								setVisible(false);
							} else {
								JOptionPane.showMessageDialog(null, "��ü�� ���еǾ����ϴ�.\n�ٽ� �õ����ּ���.", "��ü ����", JOptionPane.INFORMATION_MESSAGE);
								System.err.println("++++++ ������ü ����! ++++++");
							}
						}
					}
				} else {
					System.err.println("++++++ ���ΰ��� ��ü Fail! ++++++");
					JOptionPane.showMessageDialog(null, "���� ���·� ��ü�Ͻ� �� �����ϴ�.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			} else {
				System.err.println("++++++ �ŷ��ܾ� Fail! ++++++");
				JOptionPane.showMessageDialog(null, "�ܾ��� �����մϴ�.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		} else {
			System.err.println("++++++ ���� ��ȿ�� Fail! ++++++");
			JOptionPane.showMessageDialog(null, "���������ʴ� ���¹�ȣ�Դϴ�.\n�ٽ� Ȯ�����ּ���", "Error", JOptionPane.ERROR_MESSAGE);
		}
		
	}
}