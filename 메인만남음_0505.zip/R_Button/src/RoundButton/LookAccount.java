package RoundButton;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.biz.BankBiz;
import com.dto.BankDto;

public class LookAccount extends JFrame {

	private JPanel contentPane;
	private JTextField fName;
	private JTextField fAccount;
	private JTextField fBalance;
	private JTable lookTable;
	private DefaultTableModel model;
	private BankBiz biz = new BankBiz();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LookAccount frame = new LookAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	// �⺻ ������
	public LookAccount() {}
	
	// dto ������
	public LookAccount(BankDto dto) {
		
		setTitle("::������ȸ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		//contentPane.setLayout(null);
		
		JPanel pan00 = new JPanel();
		pan00.setBounds(0, -10, 800, 100);
		contentPane.add(pan00);
		contentPane.setLayout(null);
		ImageIcon logo00 = new ImageIcon("images/banner_showmeMoney.png");
		Image img00 = logo00.getImage();
		Image after00 = img00.getScaledInstance(800, 100, java.awt.Image.SCALE_SMOOTH);
		ImageIcon icon00 = new ImageIcon(after00);
		JLabel BanLa00 = new JLabel("");
		BanLa00.setIcon(icon00);
		BanLa00.setBounds(0, 0, 800, 100);
		pan00.add(BanLa00);
		this.getContentPane().add(pan00);
		pan00.setVisible(true);
		
		JPanel pan10 = new JPanel();
		pan10.setBounds(0, -10, 800, 100);
		contentPane.add(pan10);
		contentPane.setLayout(null);
		ImageIcon logo10 = new ImageIcon("images/banner_showmeAll.png");
		Image img10 = logo10.getImage();
		Image after10 = img10.getScaledInstance(800, 100, java.awt.Image.SCALE_SMOOTH);
		ImageIcon icon10 = new ImageIcon(after10);
		JLabel BanLa10 = new JLabel("");
		BanLa10.setIcon(icon10);
		BanLa10.setBounds(0, 0, 800, 100);
		pan10.add(BanLa10);
		this.getContentPane().add(pan10);
		pan10.setVisible(false);

		JPanel pan01 = new JPanel();
		pan01.setBounds(0, 100, 800, 200);
		contentPane.add(pan01);
		pan01.setLayout(null);
		
		fName = new JTextField();
		fName.setFont(new Font("���� ����", Font.PLAIN, 18));
		fName.setHorizontalAlignment(SwingConstants.CENTER);
		fName.setText(dto.getName());
		fName.setEditable(false);
		fName.setBackground(SystemColor.menu);
		fName.setBounds(83, 46, 169, 30);
		pan01.add(fName);
		fName.setColumns(10);
		
		fAccount = new JTextField();
		fAccount.setFont(new Font("���� ����", Font.PLAIN, 18));
		fAccount.setHorizontalAlignment(SwingConstants.CENTER);
		fAccount.setText(dto.getAccount());
		fAccount.setEditable(false);
		fAccount.setColumns(10);
		fAccount.setBounds(338, 46, 169, 30);
		pan01.add(fAccount);
		
		fBalance = new JTextField();
		fBalance.setFont(new Font("���� ����", Font.BOLD, 18));
		fBalance.setHorizontalAlignment(SwingConstants.RIGHT);
		fBalance.setText(String.format("%,d",dto.getT_balance()) + "  ");
		fBalance.setEditable(false);
		fBalance.setColumns(10);
		fBalance.setBounds(196, 106, 239, 46);
		pan01.add(fBalance);
		
		JTextField fBalKo = new JTextField();
		fBalKo.setFont(new Font("���� ����", Font.ITALIC, 13));
		fBalKo.setBorder(null);
		fBalKo.setBackground(new Color(0,0,0,0));
		fBalKo.setForeground(Color.gray);
		fBalKo.setHorizontalAlignment(SwingConstants.RIGHT);
		fBalKo.setEditable(false);
		fBalKo.setColumns(10);
		fBalKo.setBounds(196, 155, 245, 25);
		fBalKo.setBorder(null);
		fBalKo.setText(Money(dto.getT_balance()+"")+" ��");
		pan01.add(fBalKo);
		
		
		JLabel lblNewLabel = new JLabel("����");
		lblNewLabel.setBounds(276, 46, 58, 30);
		pan01.add(lblNewLabel);
		
		JLabel label = new JLabel("����");
		label.setBounds(533, 46, 58, 30);
		pan01.add(label);
		
		JLabel label_1 = new JLabel("�ܾ� : ");
		label_1.setBounds(124, 115, 58, 30);
		pan01.add(label_1);
		
		JLabel label_2 = new JLabel("��");
		label_2.setBounds(449, 115, 58, 30);
		pan01.add(label_2);
		
		JButton bBack = new JButton("���ư���");
		bBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(JOptionPane.showConfirmDialog(contentPane, "�� �������� �����ðڽ��ϱ�?", "�ǵ��� ����", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE)==0) {
					RoundButton2 roundButton2 = new RoundButton2(dto);
					roundButton2.setVisible(true);
					dispose();
				}
			}
		});
		bBack.setBounds(590, 40, 140, 40);
		bBack.setBackground(new Color(11, 162, 154));
		bBack.setForeground(new Color(255, 255, 255));	
		pan01.add(bBack);

		JPanel pan02 = new JPanel();
		pan02.setBounds(0, 300, 800, 250);
		contentPane.add(pan02);
		pan02.setLayout(null);
		
		JButton bLook = new JButton("��ȸ�ϱ�");
		bLook.setBackground(new Color(11, 162, 154));
		bLook.setForeground(new Color(255, 255, 255));
		bLook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pan02.setVisible(true);
				pan00.setVisible(false);
				pan10.setVisible(true);
				Lookup();
			}
			
			private void Lookup() {
				List<BankDto> lookList = biz.tradeList(dto.getAccount());
				if(lookList.size() == 0) {
					JOptionPane.showMessageDialog(contentPane, "�ش� ���³����� ���������ʽ��ϴ�.");
				} else {
					model.setRowCount(0);
					JOptionPane.showMessageDialog(contentPane, lookList.size() + "���� ������ �����մϴ�.");
					for (int i = 0; i < lookList.size(); i++) {
						BankDto dto = (BankDto)lookList.get(i);
						Date trade_date = dto.getTrade_date();
						String sender = dto.getSender();
						String message = dto.getMessage();
						int input = dto.getInput();
						int output = dto.getOutput();
						int balance = dto.getBalance();
						model.addRow(new Object[] {trade_date, sender, message, input, output, balance});
					}
					lookTable.setModel(model);
				}
			}
		});
		bLook.setBounds(590, 88, 142, 61);
		pan01.add(bLook);
		
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setBounds(14, 30, 99, 34);
		pan02.add(comboBox);
		comboBox.addItem("�Ա� + ���");
		comboBox.addItem("�Ա�");
		comboBox.addItem("���");
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					switch (e.getItem()+"") {
					case "�Ա� + ���":
						List<BankDto> tradeListAll = biz.tradeList(dto.getAccount());
						if(tradeListAll.size() == 0) {
							JOptionPane.showMessageDialog(contentPane, "�ŷ� ������ ���������ʽ��ϴ�.");
						} else {
							model.setRowCount(0);
							for (int i = 0; i < tradeListAll.size(); i++) {
								BankDto dto = (BankDto)tradeListAll.get(i);
								Date trade_date = dto.getTrade_date();
								String sender = dto.getSender();
								String message = dto.getMessage();
								int input = dto.getInput();
								int output = dto.getOutput();
								int balance = dto.getBalance();
								model.addRow(new Object[] {trade_date, sender, message, input, output, balance});
							}
							lookTable.setModel(model);
						}
						break;
					case "�Ա�":
						List<BankDto> tradeListIn = biz.tradeListIn(dto.getAccount());
						if(tradeListIn.size() == 0) {
							model.setRowCount(0);
							JOptionPane.showMessageDialog(contentPane, "�Աݳ����� ���������ʽ��ϴ�.");
						} else {
							model.setRowCount(0);
							JOptionPane.showMessageDialog(contentPane, tradeListIn.size() + "���� �Ա� ������ �����մϴ�.");
							for(int i =0 ;i<tradeListIn.size();i++) {
								BankDto dto = (BankDto)tradeListIn.get(i);
								Date trade_date =dto.getTrade_date();
								String sender = dto.getSender();
								String message = dto.getMessage();
								int input = dto.getInput();
								int output = dto.getOutput();
								int balance = dto.getBalance();
								model.addRow(new Object[] {trade_date,sender,message,input,output,balance});
							}
							lookTable.setModel(model);
						}
						break;
					case "���":
						List<BankDto> tradeListOut = biz.tradeListOut(dto.getAccount());
						if(tradeListOut.size() == 0) {
							model.setRowCount(0);
							JOptionPane.showMessageDialog(contentPane, "��ݳ����� �������� �ʽ��ϴ�.");
						} else {
							model.setRowCount(0);
							JOptionPane.showMessageDialog(contentPane, tradeListOut.size()+"���� ��� ������ �����մϴ�.");
							for (int i = 0; i < tradeListOut.size(); i++) {
								BankDto dto = (BankDto)tradeListOut.get(i);
								Date trade_date = dto.getTrade_date();
								String sender = dto.getSender();
								String message = dto.getMessage();
								int input = dto.getInput();
								int output = dto.getOutput();
								int balance = dto.getBalance();
								model.addRow(new Object[] {trade_date, sender, message, input, output, balance});
							}
							lookTable.setModel(model);
						}
						break;
					}
				}
			}
		});
		
		lookTable = new JTable();
		lookTable.setBackground(SystemColor.inactiveCaption);
		lookTable.setForeground(SystemColor.windowBorder);
		model = new DefaultTableModel();
		model.addColumn("�ŷ���¥");
		model.addColumn("������/�޴º�");
		model.addColumn("�۱ݸ޸�");
		model.addColumn("�Աݾ�");
		model.addColumn("��ݾ�");
		model.addColumn("�ܾ�");
		lookTable.setModel(model);
		lookTable.setSize(600,200);
		lookTable.setLocation(50,50);
		lookTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		JScrollPane scrollPane = new JScrollPane(lookTable);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(122, 30, 630, 199);
		pan02.add(scrollPane);
		pan02.setVisible(false);
		this.getContentPane().add(pan02);
		this.setVisible(true);
//		scrollPane.setColumnHeaderView(lookTable);
	
	}
	
	private String Money(String tBalance) {
		StringBuffer sb = new StringBuffer();
		String[] sta1 = {"","��","��","��","��","��","��","ĥ","��","��"};
		String[] sta2 = {"","��","��","õ"};
		String[] sta3 = {"","��","��","��"};			
		int cnt = 0;
		int leng = tBalance.length();
		int me;
		for(int i=0;i<leng;i++) {
			me = Integer.parseInt(tBalance.charAt(i)+"");
			sb.append(sta1[me]);
			if(me>0) {
				sb.append(sta2[(leng-1-i)%4]);
			}else {
				cnt++;
			}
			if((leng-1-i)%4==0) {
				if(cnt!=4) {
					sb.append(sta3[(leng-1-i)/4]);
				}
				cnt=0;
			}
		}			
		return sb.toString();
	}

}
