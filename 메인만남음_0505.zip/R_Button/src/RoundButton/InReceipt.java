package RoundButton;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;

public class InReceipt extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	JPanel check_img;
	JButton brn_confirm;
	BankBiz biz = new BankBiz();
	BankDto my = new BankDto();
	int input = 0;
	String in_message = "";
	
	public InReceipt() {
		
	}

	public InReceipt(BankDto dto, int input, String input_message) {
		this.my = dto;
		this.input = input;
		this.in_message = input_message;
		check_img = new JPanel();
		check_img.setBounds(0, 28, 464, 72);

		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		//URL imgURL = this.getClass().getResource("images/check_mark.png");
		//ImageIcon imgIcon = new ImageIcon(imgURL);
		ImageIcon imgIcon = new ImageIcon("images/check_mark.png");
		getContentPane().setLayout(null);
		
		JPanel empty = new JPanel();
		empty.setBounds(0, 0, 464, 21);
		getContentPane().add(empty);
		
		JPanel finish = new JPanel();
		finish.setBounds(0, 98, 464, 44);
		getContentPane().add(finish);
		
		JLabel label_1 = new JLabel("�Ա��� �Ϸ� �Ǿ����ϴ�!");
		label_1.setFont(new Font("��������", Font.PLAIN, 18));
		finish.add(label_1);
		
		getContentPane().add(check_img);
		check_img.setLayout(null);
		JLabel label = new JLabel("",imgIcon,SwingConstants.CENTER);
		label.setBounds(206, 18, 50, 44);
		check_img.add(label);
		
		JPanel in_money = new JPanel();
		in_money.setBounds(0, 163, 464, 72);
		getContentPane().add(in_money);
		in_money.setLayout(null);
		
		JLabel input_money = new JLabel("�Աݱݾ�");
		input_money.setHorizontalAlignment(SwingConstants.CENTER);
		input_money.setFont(new Font("��������", Font.PLAIN, 15));
		input_money.setBounds(47, 10, 71, 52);
		in_money.add(input_money);
		
		//
		JLabel in_label = new JLabel("newlabel");
		in_label.setFont(new Font("��������", Font.PLAIN, 15));
		in_label.setHorizontalAlignment(SwingConstants.RIGHT);
		in_label.setBounds(210, 20, 189, 33);
		in_money.add(in_label);
		in_label.setText(input+"��");
		
		JPanel message = new JPanel();
		message.setBounds(0, 245, 464, 72);
		
		
		getContentPane().add(message);
		message.setLayout(null);
		
		JLabel msg = new JLabel("����޸�");
		msg.setHorizontalAlignment(SwingConstants.CENTER);
		msg.setFont(new Font("��������", Font.PLAIN, 15));
		msg.setBounds(48, 10, 71, 52);
		message.add(msg);
		
		//
		JLabel msg_label = new JLabel("New label");
		msg_label.setFont(new Font("��������", Font.PLAIN, 15));
		msg_label.setHorizontalAlignment(SwingConstants.RIGHT);
		msg_label.setBounds(210, 20, 189, 33);
		message.add(msg_label);
		msg_label.setText(in_message);
		
		
		JPanel balance = new JPanel();
		balance.setBounds(0, 315, 464, 72);
		getContentPane().add(balance);
		balance.setLayout(null);

		
		JLabel bal = new JLabel("�ܾ�");
		bal.setHorizontalAlignment(SwingConstants.CENTER);
		bal.setFont(new Font("��������", Font.PLAIN, 15));
		bal.setBounds(44, 10, 71, 52);
		balance.add(bal);
		
		//
		JLabel bal_label = new JLabel("New label");
		bal_label.setFont(new Font("��������", Font.PLAIN, 15));
		bal_label.setHorizontalAlignment(SwingConstants.RIGHT);
		bal_label.setBounds(210, 20, 189, 33);
		balance.add(bal_label);
		bal_label.setText(biz.getBalance(my.getAccount())+"��");
		
		brn_confirm = new JButton("Ȯ��");//Ȯ�ι�ư
		brn_confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				RoundButton2 roundbutton2 = new RoundButton2(dto);
				roundbutton2.setVisible(true);
			}
		});
		brn_confirm.setFont(new Font("��������", Font.PLAIN, 18));
		brn_confirm.setBackground(new Color(0, 162, 154));
		brn_confirm.setBounds(256, 431, 176, 59);
		getContentPane().add(brn_confirm);
		brn_confirm.addActionListener(this);
		
		
		Dimension frameSize = this.getSize();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screenSize.width - frameSize.width)/2, (screenSize.height - frameSize.height)/2);
		setSize(480,560);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==brn_confirm) {
			dispose();
		}
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawLine(50, 190, 430, 190);
		g.drawLine(50, 270, 430, 270);
		g.drawLine(50, 350, 430, 350);
	}

	public static void main(String[] args) {
		try {
			InReceipt dialog = new InReceipt();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
