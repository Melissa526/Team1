package RoundButton;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Nopassbook extends JFrame {

	private BankBiz biz = new BankBiz();
	private JPanel contentPane;
	private JTextField accountField;
	private JTextField inputField;
	private JTextField senderField;
	private JTextField messageField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Nopassbook frame = new Nopassbook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Nopassbook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel nopassLabel = new JLabel("������ �Ա�");
		nopassLabel.setFont(new Font("���� ����", Font.BOLD, 22));
		nopassLabel.setBounds(154, 12, 159, 30);
		contentPane.add(nopassLabel);
		
		JLabel inputAccLabel = new JLabel("�Ա� ����");
		inputAccLabel.setFont(new Font("���� ����", Font.BOLD, 18));
		inputAccLabel.setBounds(45, 77, 99, 30);
		contentPane.add(inputAccLabel);
		
		JLabel inputMoneyLabel = new JLabel("��ü �ݾ�");
		inputMoneyLabel.setFont(new Font("���� ����", Font.BOLD, 18));
		inputMoneyLabel.setBounds(45, 122, 78, 30);
		contentPane.add(inputMoneyLabel);
		
		JLabel senderLabel = new JLabel("������ ���");
		senderLabel.setFont(new Font("���� ����", Font.BOLD, 18));
		senderLabel.setBounds(45, 177, 99, 18);
		contentPane.add(senderLabel);
		
		JLabel messageLabel = new JLabel("������ �޼���");
		messageLabel.setFont(new Font("���� ����", Font.BOLD, 18));
		messageLabel.setBounds(45, 222, 114, 30);
		contentPane.add(messageLabel);
		
		accountField = new JTextField();
		accountField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(accountField.getText().length() == 11 || e.getKeyChar() == KeyEvent.VK_ENTER) {
					inputField.requestFocus();
				}
			}
		});
		accountField.setBounds(198, 83, 196, 24);
		contentPane.add(accountField);
		accountField.setColumns(10);
		
		inputField = new JTextField();
		inputField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					senderField.requestFocus();
				}
			}
		});
		inputField.setBounds(198, 128, 196, 24);
		contentPane.add(inputField);
		inputField.setColumns(10);
		
		senderField = new JTextField();
		senderField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					messageField.requestFocus();
				}
			}
		});
		senderField.setBounds(198, 177, 196, 24);
		contentPane.add(senderField);
		senderField.setColumns(10);
		
		JButton inputBtn = new JButton("��    ��"); //inputBtn.requestFocus(); �����Ϸ��� ����ø�
		
		messageField = new JTextField();
		messageField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					inputBtn.requestFocus();
				}
			}
		});
		messageField.setBounds(198, 228, 196, 24);
		contentPane.add(messageField);
		messageField.setColumns(10);
		
		inputBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String account = accountField.getText();
				String input = inputField.getText();
				String sender = senderField.getText();
				String message = messageField.getText();
				if(account.equals("") || input.equals("") ||sender.equals("")) {
					JOptionPane.showMessageDialog(contentPane, "'�Ա� ����', '��ü �ݾ�', '������ ���'�� �ʼ��Է°��Դϴ�.");
				} else {
					if(account.length() == 11) {
						BankDto asisbalancedto = biz.BankBalance(account);
						BankDto trade_listdto = new BankDto(account,null,sender,message,Integer.parseInt(input),0,0);
						String res = biz.NoPassbookDeposit(account, asisbalancedto, trade_listdto);
						
						if(res.equals("11")) {
							JOptionPane.showMessageDialog(contentPane, account+"���¿� �ԱݵǾ����ϴ�!");
							dispose();
							RoundButton roundButton = new RoundButton();
							roundButton.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(contentPane, "�ŷ��� ��ҵǾ����ϴ�.");
						}
						
					}else {
						JOptionPane.showMessageDialog(contentPane, "���� ���� ���������Դϴ�.");
					}
				}
			}
		});
		inputBtn.setFont(new Font("���� ����", Font.BOLD, 18));
		inputBtn.setBounds(74, 285, 105, 40);
		contentPane.add(inputBtn);
		
		JButton cancleBtn = new JButton("��    ��");
		cancleBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RoundButton roundButton = new RoundButton();
				roundButton.setVisible(true);
				dispose();
				
			}
		});
		cancleBtn.setFont(new Font("���� ����", Font.BOLD, 18));
		cancleBtn.setBounds(235, 285, 105, 40);
		contentPane.add(cancleBtn);
	}
}
