package RoundButton;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

import com.dto.BankDto;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Color;
import javax.swing.JDesktopPane;
import java.awt.Toolkit;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Panel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.SystemColor;

public class RoundButton2 extends JFrame {


	private JPanel contentPane;
	JButton button;
	JButton button_2;
	public JButton button_4;
	public JButton getButton_4() {
		return button_4;
	}

	public void setButton_4(JButton button_4) {
		this.button_4 = button_4;
	}

	JButton button_5;
	private JButton button_1;
	private JButton button_3;
	
	/**
	 * Launch the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RoundButton2 frame = new RoundButton2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	//�⺻ ������
	public RoundButton2() {

	}
	
	// dto�޴�  ������
	public RoundButton2(BankDto logindto) {

		setBackground(new Color(0, 0, 255));
		setFont(new Font("HY������M", Font.PLAIN, 99));
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\hicja\\Pictures\\a.PNG"));
		setTitle("1�� ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setToolTipText("");
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("������ü");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TransferGUI transfergui = new TransferGUI(logindto);
				transfergui.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(51, 204, 204));
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(50, 250, 163, 40);
		panel.add(btnNewButton);
		
		button = new JButton("��   ��");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		button.setForeground(new Color(255, 255, 255));
		button.setBackground(new Color(51, 204, 204));
		button.setFont(new Font("���� ����", Font.BOLD, 18));
		button.setBounds(50, 50, 163, 40);
		panel.add(button);
		
		button_2 = new JButton("������ȸ");
		button_2.setForeground(new Color(255, 255, 255));
		button_2.setBackground(new Color(51, 204, 204));
		button_2.setFont(new Font("���� ����", Font.BOLD, 18));
		button_2.setBounds(349, 50, 163, 40);
		panel.add(button_2);
		
		button_5 = new JButton("�α׾ƿ�");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(button_5.getText() == "�α׾ƿ�") {
					RoundButton main = new RoundButton();
					main.setVisible(true);
					dispose();
				}
			}
		});
		button_5.setForeground(Color.WHITE);
		button_5.setFont(new Font("���� ����", Font.BOLD, 18));
		button_5.setBackground(new Color(51, 204, 204));
		button_5.setBounds(349, 250, 163, 40);
		panel.add(button_5);
		
		button_1 = new JButton("��   ��");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("���� ����", Font.BOLD, 18));
		button_1.setBackground(new Color(51, 204, 204));
		button_1.setBounds(50, 150, 163, 40);
		panel.add(button_1);
		
		button_3 = new JButton("�ŷ� ���� ��ȸ");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setFont(new Font("���� ����", Font.BOLD, 18));
		button_3.setBackground(new Color(51, 204, 204));
		button_3.setBounds(349, 150, 163, 40);
		panel.add(button_3);
	}

}
