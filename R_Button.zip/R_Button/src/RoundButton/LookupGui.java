package RoundButton;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.biz.BankBiz;
import com.dao.BankDao;
import com.dto.BankDto;

public class LookupGui implements ActionListener,ItemListener {
	List<BankDto> tradeList;
	BankDao dao ;
	
	JFrame frame;
	JPanel pan02;
	JTextField fname,faccount,fbalance;
	JTable Looktable;
	JButton bLookup ;
	JTextArea area;
	DefaultTableModel model;	
	String name,account;
	int balance;
	private final JPanel pan00 = new JPanel();
	private JLabel imageLabel;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LookupGui window = new LookupGui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public LookupGui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("::������ȸ::");
		frame.setForeground(Color.GRAY);
		frame.setType(Type.UTILITY);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 818, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel pan01 = new JPanel();
		pan01.setBounds(0, 100, 800, 170);
		pan01.setForeground(Color.GRAY);
		frame.getContentPane().add(pan01);
		pan01.setLayout(null);
		
		JLabel label = new JLabel("���� ");
		label.setBounds(276, 46, 58, 30);
		pan01.add(label);
		
		fname = new JTextField();
		fname.setHorizontalAlignment(SwingConstants.CENTER);
		fname.setBackground(SystemColor.menu);
		fname.setBounds(83, 46, 169, 30);
		pan01.add(fname);
		fname.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("����");
		lblNewLabel.setBounds(533, 46, 58, 30);
		pan01.add(lblNewLabel);
		
		faccount = new JTextField();
		faccount.setHorizontalAlignment(SwingConstants.CENTER);
		faccount.setFont(new Font("����", Font.PLAIN, 15));
		faccount.setBackground(SystemColor.menu);
		faccount.setBounds(338, 46, 169, 30);
		pan01.add(faccount);
		faccount.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("�ܾ�");
		lblNewLabel_1.setBounds(124, 115, 58, 30);
		pan01.add(lblNewLabel_1);
		
		fbalance = new JTextField();
		fbalance.setHorizontalAlignment(SwingConstants.RIGHT);
		fbalance.setFont(new Font("����", Font.BOLD, 17));
		fbalance.setBackground(SystemColor.menu);
		fbalance.setBounds(196, 106, 239, 46);
		pan01.add(fbalance);
		fbalance.setColumns(10);
		
		bLookup = new JButton("�ŷ�������ȸ");
		bLookup.setBackground(SystemColor.menu);
		bLookup .setBounds(587, 46, 142, 103);
		bLookup.addActionListener(this);
		pan01.add(bLookup);
		
		JLabel label_1 = new JLabel("��");
		label_1.setBounds(449, 115, 58, 30);
		pan01.add(label_1);
		
		pan02 = new JPanel();
		pan02.setBounds(0, 270, 800, 280);
		pan02.setLayout(null);
		frame.getContentPane().add(pan02);
		model = new DefaultTableModel();
		model.addColumn("���¹�ȣ");
		model.addColumn("�ŷ���¥");
		model.addColumn("������/�޴º�");
		model.addColumn("�۱ݸ޸�");
		model.addColumn("�Աݾ�");
		model.addColumn("��ݾ�");
		model.addColumn("�ܾ�");
		
		Looktable = new JTable();
		Looktable.setBackground(SystemColor.inactiveCaption);
		Looktable.setForeground(SystemColor.windowBorder);
		Looktable.setFont(new Font("����", Font.PLAIN, 15));
		
		Looktable.setModel(model);
		Looktable.setSize(600, 200);
		Looktable.setLocation(50, 50);		
		Looktable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		
		JScrollPane scrollPane01 = new JScrollPane(Looktable);
		scrollPane01.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane01.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane01.setBounds(122, 25, 630, 199);
		pan02.add(scrollPane01);
		
		JComboBox combo = new JComboBox();
		combo.setBounds(14, 25, 99, 34);
		pan02.add(combo);
		combo.addItem("�Ա�+���");
		combo.addItem("�Ա�");
		combo.addItem("���");
		combo.addItemListener(this);
		pan00.setBounds(0, 0, 800, 100);
		frame.getContentPane().add(pan00);
		pan00.setLayout(null);
		
		ImageIcon iconLogo = new ImageIcon("images/banner_showmeMy.png");
		imageLabel = new JLabel("");
		imageLabel.setIcon(iconLogo);
		imageLabel.setBounds(0, 0, 800, 100);
		pan00.add(imageLabel);
		pan02.setVisible(false);
				
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bLookup) {
			pan02.setVisible(true);
			LookupList();
			bLookup.setVisible(true);
		}
	}
	public void LookupList() {
		account = faccount.getText();
		if(account.contentEquals("")) {
			JOptionPane.showMessageDialog(null, "���¹�ȣ�� �����ε��������Ͽ���.");
		}else { 
			BankBiz biz = new BankBiz();
			BankDto dto = biz.myaccount(account);
			
			fname.setText(dto.getName());
			faccount.setText(dto.getAccount());
			fbalance.setText(""+(dto.getT_balance()));
		}
		if(account.contentEquals("")) {
			JOptionPane.showMessageDialog(null, "���¹�ȣ�� �����ε��������Ͽ���.");
		}else {
			BankBiz biz = new BankBiz();
			tradeList = biz.tradeList(account);
			
			if(tradeList.size()==0) {
				JOptionPane.showMessageDialog(null, "�ش���°������ϴ�.");
			}else {
				model.setRowCount(0);
				JOptionPane.showMessageDialog(null,tradeList.size()+"���� ������ �����մϴ�.");
				for(int i = 0 ; i<tradeList.size();i++) {
				BankDto dto = (BankDto)tradeList.get(i);
				
				String account =dto.getAccount();
				Date trade_date =dto.getTrade_date();
				String sender = dto.getSender();
				String message = dto.getMessage();
				int input = dto.getInput();
				int output = dto.getOutput();
				int balance = dto.getBalance();
				
				model.addRow(new Object[] {account,trade_date,sender,message,input,output,balance});	
				}

				Looktable.setModel(model);
			}
		
		
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		
		Object obj = e.getItem();
		account = faccount.getText();
		BankBiz biz = new BankBiz();
		BankDto dto = biz.myaccount(account);
		
		if(obj.equals("�Ա�+���")) {
			List<BankDto> tradeListAll = biz.tradeList(account);
			if(tradeList.size()==0) {
				JOptionPane.showMessageDialog(null, "�ش系���̾����ϴ�.");
			}else {
				model.setRowCount(0);
				for(int i = 0 ; i<tradeListAll.size();i++) {
				dto = (BankDto)tradeListAll.get(i);
				
				String account =dto.getAccount();
				Date trade_date =dto.getTrade_date();
				String sender = dto.getSender();
				String message = dto.getMessage();
				int input = dto.getInput();
				int output = dto.getOutput();
				int balance = dto.getBalance();
				
				model.addRow(new Object[] {account,trade_date,sender,message,input,output,balance});	
				}

				Looktable.setModel(model);
			}
		}else if(obj.equals("�Ա�")) {
			List<BankDto> tradeListIn = biz.tradeListIn(account);
			if(tradeListIn.size()==0) {
				JOptionPane.showMessageDialog(null, "�Աݳ����� ���������ʽ��ϴ�.");
			}else {
				model.setRowCount(0);
				JOptionPane.showMessageDialog(null,tradeListIn.size()+"���� �Ա� ������ �����մϴ�.");
				for(int i = 0 ; i<tradeListIn.size();i++) {
				dto = (BankDto)tradeListIn.get(i);
				
				String account =dto.getAccount();
				Date trade_date =dto.getTrade_date();
				String sender = dto.getSender();
				String message = dto.getMessage();
				int input = dto.getInput();
				int output = dto.getOutput();
				int balance = dto.getBalance();
				
				model.addRow(new Object[] {account,trade_date,sender,message,input,output,balance});	
				}

				Looktable.setModel(model);
			}
		}else if(obj.equals("���")) {
			List<BankDto> tradeListOut = biz.tradeListOut(account);
			if(tradeListOut.size()==0) {
				JOptionPane.showMessageDialog(null, "��ݳ����� �������� �ʽ��ϴ�.");
			}else {
				model.setRowCount(0);
				JOptionPane.showMessageDialog(null,tradeListOut.size()+"���� ��� ������ �����մϴ�.");
				for(int i = 0 ; i<tradeListOut.size();i++) {
				dto = (BankDto)tradeListOut.get(i);
				
				String account =dto.getAccount();
				Date trade_date =dto.getTrade_date();
				String sender = dto.getSender();
				String message = dto.getMessage();
				int input = dto.getInput();
				int output = dto.getOutput();
				int balance = dto.getBalance();
				
				model.addRow(new Object[] {account,trade_date,sender,message,input,output,balance});	
				}

				Looktable.setModel(model);
			}
		}
		
	}
}