package RoundButton;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public // ���ζߴ� �α���â
class Login extends JDialog implements ActionListener {

	BankBiz biz = new BankBiz();
	BankDto logindto = null;
	private JPanel contentPane;
	private JTextField idField;
	private JPasswordField passwordField;
	private JButton button;
	private JButton button_1;
	public boolean loginTF;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		loginTF = true;
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblID = new JLabel("I   D");
		lblID.setFont(new Font("���� ����", Font.BOLD, 20));
		lblID.setBounds(50, 62, 62, 18);
		contentPane.add(lblID);
		
		JLabel lblPW = new JLabel("P   W");
		lblPW.setFont(new Font("���� ����", Font.BOLD, 20));
		lblPW.setBounds(50, 138, 62, 18);
		contentPane.add(lblPW);
		
		//textField ���̵��Է�ĭ
		idField = new JTextField();
		idField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(idField.getText().length() == 11) {
					passwordField.requestFocus();
				}
			}
		});
		idField.setBounds(147, 63, 171, 24);
		contentPane.add(idField);
		idField.setColumns(10);
		//��й�ȣ �Է�ĭ
		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(passwordField.getText().length() == 4) {
					button.requestFocus();
				}
			}
		});
		passwordField.setBounds(147, 139, 171, 24);
		contentPane.add(passwordField);
		
		button = new JButton("�α���");
		button.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if(e.getKeyChar() == KeyEvent.VK_ENTER) {
					String account = idField.getText();
					System.out.println(account);
					String password = passwordField.getText();
					System.out.println(password);
					logindto = biz.login(account, password);
					
					if (logindto.getAccount() != null) {
						
					RoundButton2 roundbutton2 = new RoundButton2(logindto);
					RoundButton main = new RoundButton();
					main.setVisible(false);
					roundbutton2.setVisible(true);
					dispose();
					main.dispose();
					}else {
						System.out.println("���¹�ȣ �Ǵ� ��й�ȣ�� �߸� �Է��ϼ̽��ϴ�. �ʱ� ȭ������ ���ư��ϴ�.");
					}
				}
			}
		});
		button.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {

				String account = idField.getText();
				System.out.println(account);
				String password = passwordField.getText();
				System.out.println(password);
				logindto = biz.login(account, password);
				
				if (logindto.getAccount() != null) {
					
				RoundButton2 roundbutton2 = new RoundButton2(logindto);
				RoundButton main = new RoundButton();
				main.setVisible(false);
				roundbutton2.setVisible(true);
				dispose();
				main.dispose();
				}else {
					System.out.println("���¹�ȣ �Ǵ� ��й�ȣ�� �߸� �Է��ϼ̽��ϴ�. �ʱ� ȭ������ ���ư��ϴ�.");
				}
			}
		});
		
		button.addActionListener(this);
		button.setBounds(195, 214, 105, 27);
		contentPane.add(button);
		
		button_1 = new JButton("��  ��");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				RoundButton main = new RoundButton();
				main.setVisible(true);
			}
		});
		button_1.setBounds(313, 214, 105, 27);
		contentPane.add(button_1);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
	}
}
