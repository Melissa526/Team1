package RoundButton;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;

public class Nopassbook extends JFrame {

	private BankBiz biz = new BankBiz();
	private JPanel contentPane;
	private JTextField accountField;
	private JTextField inputField;
	private JTextField senderField;
	private JTextField messageField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Nopassbook frame = new Nopassbook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Nopassbook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\uBB34\uD1B5\uC7A5 \uC785\uAE08");
		label.setFont(new Font("���� ����", Font.BOLD, 22));
		label.setBounds(154, 12, 159, 30);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("\uC785\uAE08 \uACC4\uC88C");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel.setBounds(45, 77, 99, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC774\uCCB4 \uAE08\uC561");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_1.setBounds(45, 122, 78, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uBCF4\uB0B4\uB294 \uC0AC\uB78C");
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_2.setBounds(45, 177, 99, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uBCF4\uB0B4\uB294 \uBA54\uC138\uC9C0");
		lblNewLabel_3.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_3.setBounds(45, 222, 114, 30);
		contentPane.add(lblNewLabel_3);
		
		accountField = new JTextField();
		accountField.setBounds(198, 83, 196, 24);
		contentPane.add(accountField);
		accountField.setColumns(10);
		
		inputField = new JTextField();
		inputField.setBounds(198, 128, 196, 24);
		contentPane.add(inputField);
		inputField.setColumns(10);
		
		senderField = new JTextField();
		senderField.setBounds(198, 177, 196, 24);
		contentPane.add(senderField);
		senderField.setColumns(10);
		
		messageField = new JTextField();
		messageField.setBounds(198, 228, 196, 24);
		contentPane.add(messageField);
		messageField.setColumns(10);
		
		JButton resultButton = new JButton("��    ��");
		resultButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String account = accountField.getText();
				String input = inputField.getText();
				String sender = senderField.getText();
				String message = messageField.getText();
				if(account.equals("") || input.equals("") ||sender.equals("")) {
					JOptionPane.showMessageDialog(null, "'�Ա� ����', '��ü �ݾ�', '������ ���'�� �ʼ��Է°��Դϴ�.");
				} else {
					if(account.length() == 11) {
						BankDto asisbalancedto = biz.BankBalance(account);
						BankDto trade_listdto = new BankDto(account,null,sender,message,Integer.parseInt(input),0,0);
						String res = biz.NoPassbookDeposit(account, asisbalancedto, trade_listdto);
						
						if(res.equals("11")) {
							JOptionPane.showMessageDialog(null, account+"���¿� �ԱݵǾ����ϴ�!");
							dispose();
							RoundButton roundButton = new RoundButton();
							roundButton.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(null, "�ŷ��� ��ҵǾ����ϴ�.");
						}
						
					}else {
						JOptionPane.showMessageDialog(null, "���� ���� ���������Դϴ�.");
					}
				}
			}
		});
		resultButton.setFont(new Font("���� ����", Font.BOLD, 18));
		resultButton.setBounds(74, 285, 105, 40);
		contentPane.add(resultButton);
		
		JButton resetButton_1 = new JButton("��    ��");
		resetButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RoundButton roundButton = new RoundButton();
				roundButton.setVisible(true);
				dispose();
				
			}
		});
		resetButton_1.setFont(new Font("���� ����", Font.BOLD, 18));
		resetButton_1.setBounds(235, 285, 105, 40);
		contentPane.add(resetButton_1);
	}
}
