package RoundButton;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import com.biz.BankBiz;
import com.dto.BankDto;

import oracle.net.aso.r;
import javax.swing.SwingConstants;

public class Register extends JFrame {

	private BankBiz biz = new BankBiz();
	private JPanel contentPane;
	private JTextField nameField;
	private JTextField accountField;
	private JPasswordField passwordField;
	private UIManager ui = new UIManager();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 595, 393);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label_1 = new JLabel("���� ����");
		label_1.setFont(new Font("���� ����", Font.BOLD, 30));
		label_1.setBounds(210, 26, 140, 40);
		contentPane.add(label_1);

		JLabel label = new JLabel("��      ��");
		label.setFont(new Font("���� ����", Font.BOLD, 22));
		label.setBounds(132, 96, 100, 30);
		contentPane.add(label);

		nameField = new JTextField();
		nameField.setBounds(246, 96, 200, 30);
		contentPane.add(nameField);
		nameField.setColumns(10);
		nameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				JTextField src = (JTextField) ke.getSource();
				if (src.getText().length() >= 5)
					ke.consume();
			}
		});

		accountField = new JTextField();
		LimitFont lf = new LimitFont();

		JLabel label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_2.setFont(new Font("���� ����", Font.BOLD, 22));
		label_2.setBounds(132, 156, 100, 30);
		contentPane.add(label_2);

		passwordField = new JPasswordField();
		passwordField.setBounds(246, 156, 200, 30);
		contentPane.add(passwordField);
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				JTextField src = (JTextField) ke.getSource();
				if (src.getText().length() >= 15)
					ke.consume();
			}
		});

		JLabel label_3 = new JLabel("\uACC4\uC88C\uBC88\uD638");
		label_3.setFont(new Font("���� ����", Font.BOLD, 22));
		label_3.setBounds(132, 215, 100, 30);
		contentPane.add(label_3);
		accountField.setDocument(lf);
		accountField.setColumns(10);
		accountField.setBounds(246, 214, 200, 30);
		contentPane.add(accountField);

		JButton btnNewButton = new JButton("��   ��");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String name = nameField.getText();
				String password = passwordField.getText();
				String account = accountField.getText();
				
				if (account.length() == 11) {
					BankDto insertdto = new BankDto(account, name, password, 0, null);
					int accountinsert = biz.AccountCreate(insertdto);
					if (accountinsert > 0) {
						System.out.println("���°��� ����");
						JOptionPane.showMessageDialog(null, name + "���� ���°� �����Ǿ����ϴ�.");
						dispose();
						RoundButton roundButton = new RoundButton();
						roundButton.setVisible(true);
					} else {
						System.out.println("���°��� ����");
						JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �����Դϴ�.");
						accountField.setText("");
						nameField.setText("");
						passwordField.setText("");
					}
				}else {
					JOptionPane.showMessageDialog(null, "<html><body><p style=\"text-align: center; font-size: 15pt;\"> ���¹�ȣ�� ������ �߸��Ǿ����ϴ�. <br/>ex) 01012345678 </p></body></html>");
				}

			}
		});
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 22));
		btnNewButton.setBounds(120, 277, 141, 48);
		contentPane.add(btnNewButton);

		JButton button = new JButton("��   ��");
		button.setFont(new Font("���� ����", Font.BOLD, 22));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RoundButton roundButton = new RoundButton();
				roundButton.setVisible(true);
				dispose();
			}
		});
		button.setBounds(308, 277, 141, 48);
		contentPane.add(button);
		accountField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				JTextField src = (JTextField) ke.getSource();
				if (src.getText().length() >= 12)
					ke.consume();
			}
		});
	}
}
